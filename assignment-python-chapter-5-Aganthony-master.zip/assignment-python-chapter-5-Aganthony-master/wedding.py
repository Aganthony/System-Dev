# Follow the instructions for how to code this application

Wed_guest_list = []
i = 1
while i < 50:
    guest_name = input("Enter a guest's name or type 'end' to stop.")
    Wed_guest_list.append(guest_name)
    i += 1
    print(f"{guest_name}")
    if guest_name.casefold() == 'end':
        guest_list = Wed_guest_list[:-1]
        guest_list = [i for i in guest_list if i]
        break
    elif guest_name == '':
        print('Invalid Entry, Please Try Again')
print('\n'.join(map(str, guest_list)))
print(
    f"You have invited {len(guest_list)} guests at a cost of ${12 * len(guest_list)}.00.")
# print(sum(guest_list))

guest_name = "peter"
