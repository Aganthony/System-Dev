# DO NOT EDIT THIS TEST FILE
# This app tests the calc_payroll_tax() function
# How to import a function from another file
# You may see an error on line 6 until you finish creating calc_payroll_tax() in payroll.py. That's ok.
# Notice calc_payroll_tax() is in payroll.py file, not the current file
# The correct answers output by testpayroll.py are found in the instructions.

from payroll import calc_payroll_tax

calc_payroll_tax(200)
print("-" * 20)

calc_payroll_tax(4000)
print("-" * 20)

calc_payroll_tax(21000)
print("-" * 20)
