# Determines the shipping cost based on the ship_to_state.
# When testing, change the ship_to_state to various state abreviations
# to verify your code works for all conditions.

# print("Shipping to UT costs 12.5")
ship_to_state = input(
    "Enter a state to ship to, e.g. TX, NM, OK, NM, AK, HI, etc.:")
ship_to_state = ship_to_state.upper()
if ship_to_state.upper() == "TX" or ship_to_state.upper() == "NM" or ship_to_state.upper() == "OK":
    shipping_cost = 0
    print("Shipping to", ship_to_state, "costs", shipping_cost)
elif ship_to_state.upper() == "NY":
    shipping_cost = 7
    print("Shipping to", ship_to_state, "costs", shipping_cost)
elif ship_to_state.upper() == "AK":
    shipping_cost = 15.75
    print("Shipping to", ship_to_state, "costs", shipping_cost)
elif ship_to_state.upper() == "HI":
    shipping_cost = 20
    print("Shipping to", ship_to_state, "costs", shipping_cost)

else:
    print("Shipping to", ship_to_state.upper(), "costs", 12.5)
